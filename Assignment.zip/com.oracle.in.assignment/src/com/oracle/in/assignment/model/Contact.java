package com.oracle.in.assignment.model;

public class Contact {

	private String name;
	private String number;
	private String city;
	
	public Contact(String name, String number, String city) {
		this.name = name;
		this.number = number;
		this.city = city;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
