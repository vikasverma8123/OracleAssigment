package com.oracle.in.assignment.perspective;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

import com.oracle.in.assignment.view.ContactView;
import com.oracle.in.assignment.view.ShowContactView;
import com.oracle.in.assignment.view.WeatherView;

public class Perspective implements IPerspectiveFactory 
{
	public void createInitialLayout(IPageLayout layout) 
	{
		IFolderLayout folderLayout = layout.createFolder("Folder", IPageLayout.LEFT, 0.0f, layout.getEditorArea());
		folderLayout.addView(ContactView.ID);
		folderLayout.addView(ShowContactView.ID);
		folderLayout.addView(WeatherView.ID);
		
	}
}
