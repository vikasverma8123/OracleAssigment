package com.oracle.in.assignment.view;

import java.util.List;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.oracle.in.assignment.SWTResourceManager;
import com.oracle.in.assignment.file.utils.JsonHandler;
import com.oracle.in.assignment.model.Contact;

public class ShowContactView extends ViewPart {
	public ShowContactView() {
	}
	public static final String ID = "com.in.oracle.assignment.view";

	
	private TableViewer viewer;
	
	private class StringLabelProvider extends ColumnLabelProvider {
		
		// getText method is used from super class ColumnLabelProvider

		@Override
		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJ_ELEMENT);
		}
	}

	@Override
	public void createPartControl(Composite parent) {
		viewer = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		createColumns(parent, viewer);
		final Table table = viewer.getTable();
		setTableProperty(table);
		TableViewerColumn column = new TableViewerColumn(viewer, SWT.NONE);
		column.setLabelProvider(new StringLabelProvider());
		viewer.getTable().getColumn(0).setWidth(200);
		
		viewer.setContentProvider(ArrayContentProvider.getInstance());
		
		// Provide the input to the ContentProvider
		viewer.setInput(createInitialDataModel());
			}

	@Override
	public void setFocus() {
		viewer.getControl().setFocus();
		viewer.setInput(createInitialDataModel());
		viewer.refresh();

	}
	
	private List<Contact> createInitialDataModel() {
		return JsonHandler.INSTANCE.getContactList();
	}
	
	private void createColumns(final Composite parent, final TableViewer viewer) {
        String[] titles = { "Name", "Number", "City" };
        int[] bounds = { 100, 100, 100};

        // First column is for the name
        TableViewerColumn col = createTableViewerColumn(titles[0], bounds[0], 0);
        col.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public String getText(Object element) {
                Contact p = (Contact) element;
                return p.getName();
            }
        });

        // Second column is for the number
        col = createTableViewerColumn(titles[1], bounds[1], 1);
        col.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public String getText(Object element) {
            	Contact p = (Contact) element;
                return String.valueOf(p.getNumber());
            }
        });

        // Third column is for the city
        col = createTableViewerColumn(titles[2], bounds[2], 2);
        col.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public String getText(Object element) {
            	Contact p = (Contact) element;
                return p.getCity();
            }
        });
    }

	private TableViewerColumn createTableViewerColumn(String title, int bound,
            final int colNumber) {
        final TableViewerColumn viewerColumn = new TableViewerColumn(viewer,
                SWT.NONE);
        final TableColumn column = viewerColumn.getColumn();
        column.setText(title);
        column.setWidth(bound);
        column.setResizable(true);
        column.setMoveable(true);
        
        return viewerColumn;
    }
	
	private void setTableProperty(final Table table) {
		table.setHeaderBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		table.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		table.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
        table.setHeaderVisible(true);
        table.setLinesVisible(true);
	}
}