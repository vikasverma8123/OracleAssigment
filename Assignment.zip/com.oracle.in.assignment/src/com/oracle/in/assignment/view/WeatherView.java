package com.oracle.in.assignment.view;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.oracle.in.assignment.SWTResourceManager;
import com.oracle.in.assignment.file.utils.JsonHandler;
import com.oracle.in.assignment.model.Contact;
import com.oracle.in.assignment.weather.WeatherReader;


public class WeatherView extends ViewPart {

	public static final String ID = "com.in.oracle.assignment.weather";
	private Text textWeather;
	private Text textNumber;
	private Text textCity;
	private Combo combo;
	private WeatherReader weatherReader;

	public WeatherView() {
		weatherReader = new WeatherReader();
	}

	@Override
	public void createPartControl(Composite parent) {
		
		Composite composite = new Composite(parent, SWT.None);
		composite.setLayout(new GridLayout(3, false));
	
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setToolTipText("Person Name");
		lblName.setText("Name: ");
		lblName.setLayoutData(new GridData(SWT.FILL, SWT.LEFT, true, false, 1, 1));
		
		combo = new Combo(composite, SWT.NONE);
		GridData gd_combo = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_combo.widthHint = 265;
		combo.setLayoutData(gd_combo);
		updateValue();
        combo.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				setValues(parent.getShell(), combo.getText());
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
			}
		});
		
		Label lblTodaysWeather = new Label(composite, SWT.NONE);
		lblTodaysWeather.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblTodaysWeather.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		lblTodaysWeather.setText("Today's weather");
		
		Label lblNumber = new Label(composite, SWT.NONE);
		lblNumber.setText("Number: ");
		
		textNumber = new Text(composite, SWT.BORDER);
		textNumber.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
				
				
		textWeather = new Text(composite, SWT.BORDER);
		textWeather.setToolTipText("Current weather");
		textWeather.setBackground(SWTResourceManager.getColor(SWT.COLOR_INFO_BACKGROUND));
		textWeather.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
				
		Label lblCity = new Label(composite, SWT.NONE);
		lblCity.setText("City: ");
		
		textCity = new Text(composite, SWT.BORDER);
		textCity.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
				
		Button btnRefresh = new Button(composite, SWT.NONE);
		btnRefresh.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		btnRefresh.setText("Refresh");
		btnRefresh.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				refreshWeather(parent.getShell());
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				
			}
		});

	}

	@Override
	public void setFocus() {
		combo.setFocus();
		updateValue();
		textNumber.setText("");
		textCity.setText("");
		textWeather.setText("");
	}

	private void updateValue() {
		String[] contactsName = JsonHandler.INSTANCE.getContactNameList().toArray(new String[0]);
        combo.setItems(contactsName);
	}
	private void setValues(Shell shell, String text)
	{
		Contact contact = JsonHandler.INSTANCE.getContactByName(text);
		textNumber.setText(String.valueOf(contact.getNumber()));
		textCity.setText(contact.getCity());
		updateWeather(shell);
	}
	
	private void refreshWeather(Shell shell) {
		updateWeather(shell);
	}

	private void updateWeather(Shell shell) {
		String updatedData = weatherReader.getCurrentWeather(textCity.getText());
		if (updatedData.isEmpty()) {
			textWeather.setText("");
			MessageDialog.openError(shell, "Error", "Unable to featch weather update - server issue");
			
		} else if (updatedData.equalsIgnoreCase("404")) {

			textWeather.setText("");
			MessageDialog.openError(shell, "Error", "Unable to featch weather update - city not found");

		}else if (updatedData.equalsIgnoreCase("missing api key")) {
			textWeather.setText("");
			MessageDialog.openError(shell, "Error", "Please provide weather api key in weather.properties file.");
		} else {
			textWeather.setText(updatedData);
		}
	}
}
