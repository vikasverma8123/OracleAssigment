package com.oracle.in.assignment.view;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.oracle.in.assignment.file.utils.JsonHandler;
import com.oracle.in.assignment.model.Contact;

public class ContactView extends ViewPart {
	
	public static final String ID = "com.in.oracle.assignment.contact";
	private Text textName;
	private Text textNumber;
	private Text textCity;
	private Button btnSave;

	public ContactView() {
	}

	@Override
	public void createPartControl(Composite parent) 
	{
		Composite composite = new Composite(parent,SWT.NONE);
		composite.setLayout(new GridLayout(3, false));

		Label lblContact = new Label(composite, SWT.NONE);
		lblContact.setAlignment(SWT.CENTER);
		lblContact.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, true, false, 3, 1));
		lblContact.setText("New Contact");

		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setAlignment(SWT.CENTER);
		lblName.setText("Name*");
		GridData gd_lblName = new GridData(SWT.CENTER, SWT.TOP, false, false, 1, 1);
		gd_lblName.widthHint = 180;
		lblName.setLayoutData(gd_lblName);

		textName = new Text(composite, SWT.BORDER);
		textName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		

		Label lblNumber = new Label(composite, SWT.NONE);
		lblNumber.setText("Number*");
		lblNumber.setLayoutData(new GridData(SWT.CENTER, SWT.TOP, false, false, 1, 1));

		textNumber = new Text(composite, SWT.BORDER);
		textNumber.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		textNumber.setTextLimit(10);

		Label lblCity = new Label(composite, SWT.NONE);
		lblCity.setText("City*");
		lblCity.setLayoutData(new GridData(SWT.CENTER, SWT.TOP, false, false, 1, 1));

		textCity = new Text(composite, SWT.BORDER);
		textCity.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		new Label(composite, SWT.NONE);
		
		btnSave = new Button(composite, SWT.NONE);
		GridData gd_btnSave_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnSave_1.widthHint = 88;
		btnSave.setLayoutData(gd_btnSave_1);
		btnSave.setText("Save");
		
		
		btnSave.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (validateInput(parent.getShell())) {
					JsonHandler.INSTANCE
							.writeDataToFile(new Contact(textName.getText(), textNumber.getText(), textCity.getText()));
					MessageDialog.openInformation(parent.getShell(), "Info", "Contact information added sucessfully.");
				    resetInputs();
				}
			}
		});
		
		Button btnReset = new Button(composite, SWT.NONE);
		GridData gd_btnReset = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnReset.widthHint = 88;
		btnReset.setLayoutData(gd_btnReset);
		btnReset.setText("Reset");
		
		btnReset.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				resetInputs();
			}
		});
	}

	@Override
	public void setFocus() {
		textName.setFocus();
	}

	private boolean validateInput(Shell shell) {
		
		if (textName.getText().isEmpty() || textNumber.getText().isEmpty() || textCity.getText().isEmpty()) {
			MessageDialog.openError(shell, "Error", "All inputs filed are mandatory.");
		   return false;
		}else if (textNumber.getText().matches("[0-9]+") == false || textNumber.getText().length() != 10) {
			MessageDialog.openError(shell, "Error", "Please provide 10 digit mobile number.");
			return false;
		}
       return true;
	}
	
	private void resetInputs() {
		textName.setText("");
		textNumber.setText("");
		textCity.setText("");
	}
	
}
