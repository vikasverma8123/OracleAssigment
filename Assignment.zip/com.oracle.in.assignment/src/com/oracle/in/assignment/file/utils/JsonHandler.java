package com.oracle.in.assignment.file.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.oracle.in.assignment.model.Contact;

@SuppressWarnings("unchecked")
public enum JsonHandler {
	INSTANCE;

	private ArrayList<Contact> contactList;

	private JsonHandler() {
		
	}

	public void writeDataToFile(Contact contact) {
		try {
			File file = new File(ProjectProperties.getPropertyValue("path")+ "/ContactDetails.json");// loadResource();
			createJson(contact, file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createJson(Contact contact, File file) throws IOException, ParseException, FileNotFoundException {
		
		JSONObject contactObj = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		Map<String, String> contactMap = new LinkedHashMap<String, String>(2);
		contactMap.put("Name", contact.getName());
		contactMap.put("Number", String.valueOf(contact.getNumber()));
		contactMap.put("City", contact.getCity());

		jsonArray.add(contactMap);
		contactObj.put("Contacts", jsonArray);
		if (file.exists()) {
			JSONParser parser = new JSONParser();
			JSONObject jsonObj = (JSONObject) parser.parse(new FileReader(file));
			JSONArray contacts = (JSONArray) jsonObj.get("Contacts");
			contacts.add(contactMap);
			updateFile(file, jsonObj);
			readDataFromFile(file);

		} else {
			updateFile(file, contactObj);
		}
	}

	private void updateFile(File file, JSONObject jsonObj) throws IOException {
		FileWriter fileWriter = new FileWriter(file); // writing back to the file
		fileWriter.write(jsonObj.toJSONString());
		fileWriter.flush();
		fileWriter.close();
	}

	public ArrayList<Contact> readDataFromFile(File file) {
		contactList = new ArrayList<>();
		
		try {
			if (file.exists()) {
				JSONParser parser = new JSONParser();
				JSONObject jsonObj = (JSONObject) parser.parse(new FileReader(file));
				JSONArray contacts = (JSONArray) jsonObj.get("Contacts");
				for (int i = 0; i < contacts.size(); i++) {
					JSONObject obj = (JSONObject) contacts.get(i);
					Contact contact = new Contact((String) obj.get("Name"), (String) obj.get("Number"),
							(String) obj.get("City"));
					contactList.add(contact);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return contactList;
	}

	/*private File loadResource() {
		File file = null;
		Bundle bundle = FrameworkUtil.getBundle(getClass());
		URL entry = bundle.getEntry(".");
		try {
			String path = FileLocator.toFileURL(entry).getPath();
			file = new File(path + "/ContactDetails.json");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file;
	}*/
	
	public ArrayList<Contact> getContactList() {
		loadModel();
		return contactList;
	}

	public Contact getContactByName(String name) {
		loadModel();
		return contactList.stream().filter(obj -> obj.getName().equalsIgnoreCase(name)).findAny().orElse(null);
	}

	public List<String> getContactNameList() {
		loadModel();
		return contactList.stream().map(obj -> obj.getName()).collect(Collectors.toList());
	}
	private void loadModel() {
		if (contactList ==null || contactList.isEmpty()) {
			readDataFromFile(new File(ProjectProperties.getPropertyValue("path")+ "/ContactDetails.json"));
		}
	}
}
