package com.oracle.in.assignment.file.utils;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

public class ProjectProperties {

	public static String getPropertyValue(String key) {
		FileReader reader;
		try {
			Bundle bundle = FrameworkUtil.getBundle(ProjectProperties.class);
			URL url = FileLocator.find(bundle, new Path("/project.properties"));
			URL fileURL = FileLocator.toFileURL(url);
			reader = new FileReader(fileURL.getFile());
			Properties p = new Properties();
			p.load(reader);
			return p.getProperty(key);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
