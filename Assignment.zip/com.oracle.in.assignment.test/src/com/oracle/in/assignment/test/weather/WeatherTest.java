package com.oracle.in.assignment.test.weather;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.oracle.in.assignment.weather.WeatherReader;

public class WeatherTest {

	WeatherReader weatherReader;

	@Before
	public void setUp() {
		weatherReader = new WeatherReader();
	}

	@Test
	public void getWeathertest() {
		String status = weatherReader.getCurrentWeather("Pune");
		Assert.assertNotNull(status);
	}

	@Test
	public void getWrongCityWeathertest() {
		String status = weatherReader.getCurrentWeather("WrongCity");
		Assert.assertEquals("Shall return error", "404", status);
	}

}
