package com.oracle.in.assignment.test.model;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import org.eclipse.core.runtime.FileLocator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.oracle.in.assignment.file.utils.JsonHandler;
import com.oracle.in.assignment.model.Contact;

public class ModelProviderTest {

	JsonHandler modelProvider;
	File file;

	@Before
	public void setUp() {
		modelProvider = JsonHandler.INSTANCE;
	}

	@Test
	public void JsonReader() {
		loadResource("/resource/ContactDetails.json");
		ArrayList<Contact> contacts = modelProvider.readDataFromFile(file);
		Assert.assertEquals(4, contacts.size());
	}

	@Test
	public void jsonWritertest() {
		loadResource("/ContactDetails.json");
		try {
			modelProvider.createJson(new Contact("TestName", "8888888888", "pune"), file);

			ArrayList<Contact> contacts = modelProvider.readDataFromFile(file);
			Assert.assertEquals("TestName", contacts.get(0).getName());
			Assert.assertEquals("8888888888", contacts.get(0).getNumber());
			Assert.assertEquals("pune", contacts.get(0).getCity());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void loadResource(String fileName) {
		Bundle bundle = FrameworkUtil.getBundle(getClass());
		URL entry = bundle.getEntry(".");
		try {
			String path = FileLocator.toFileURL(entry).getPath();
			file = new File(path + fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
